({
    setHourList : function(component){
        var hours=component.get("v.hours");        
        if(component.get("v.timeFormat")==12){
            hours.push('12 AM');
            for(var i=1;i<12;i++)
                hours.push(i<10?('0'+i+' AM'):(i+' AM'));  
            hours.push('12 PM');
            for(var i=1;i<12;i++)
                hours.push(i<10?('0'+i+' PM'):(i+' PM'));
            hours.push('12 AM');
        }
        else{
            for(var i=0;i<=24;i++){
                hours.push(i<10?('0'+i):i);
            }
        }
        component.set("v.hours", hours);
    },
    setMinuteList : function(component){
        var minutes=component.get("v.minutes");
        for(var i=0;i<60;i+=15){
            minutes.push(''+i);
        }
        component.set("v.minutes", minutes);
    },
})