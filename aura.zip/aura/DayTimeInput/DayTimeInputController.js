({
    doInit : function(component, event, helper) {
        helper.setHourList(component);
        helper.setMinuteList(component);
    }
})