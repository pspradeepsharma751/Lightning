({
	doInit : function(component, event, helper) {
        var action = component.get("c.getAccessForAction");
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                var objAction = response.getReturnValue();
                if(!objAction['adsalescloud__Proposal_Billing_Source__c']){
                    objAction['adsalescloud__Proposal_Billing_Source__c'] = 'Contracted';
                    objAction['adsalescloud__Proposal_Billing_Schedule__c'] = 'Prepaid';
                     objAction['adsalescloud__Proposal_Caps_and_Rollovers__c'] = 'No cap';
                }
		
                component.set("v.objAction", objAction);
            }
            else{
                component.set('v.message','ERROR occured while getting application settings.');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
	
	},
	saveDFPActionJS : function(component, event, helper) {
	   	var objAction = component.get("v.objAction");
        if(objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Actual (DFP volume)' ||
           objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Actual (third party volume)'){
            	objAction['adsalescloud__Proposal_Billing_Schedule__c'] = null;
        } else if(objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Contracted' ||
                  objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Contracted Flat fee'){
            	objAction['adsalescloud__Proposal_Caps_and_Rollovers__c'] = null;
        }
        var action = component.get("c.saveDFPAction");
        action.setParams({"objAction" : objAction});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                component.set('v.message','Application Settings updated successfully.');
                component.set('v.messageType', $A.get("$Label.c.SUCCESS"));
            }
            else{
                component.set('v.message','ERROR occured while updating application settings.');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
	},
    
    handlePickListEvent: function(component, event, helper) {
        var updateRecordByEvent = event.getParam('updateRecordByEvent');
        var objAction = component.get("v.objAction");
        if(objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Actual (DFP volume)' ||
           objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Actual (third party volume)'){
            	component.set('v.objAction.adsalescloud__Proposal_Caps_and_Rollovers__c', updateRecordByEvent);

        } else if(objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Contracted' ||
                  objAction['adsalescloud__Proposal_Billing_Source__c'] == 'Contracted Flat fee'){
            component.set('v.objAction.adsalescloud__Proposal_Billing_Schedule__c', updateRecordByEvent);

        }
       
    },
})