({
    doInit : function(component, event, helper) {
		helper.initializeTableData(component);
	},
    showDayTime : function(component, event, helper){
        component.set("v.showDayTime", true);
    },
    updateJSON : function(component, event, helper){
        if(component.get("v.showDayTime") == false){
            helper.updateJSON(component);
        }        
    }
})