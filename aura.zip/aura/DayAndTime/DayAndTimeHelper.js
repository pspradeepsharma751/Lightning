({
  initializeTableData: function(component) {
    var defaultSchedule = {'start': {'hour': '0', 'minute': '0'}, 'end': {'hour': '24', 'minute': '0'}};
    var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    var tableData = component.get("v.tableData");
    var dayDetail;
      var self = this;
    if(!component.get("v.newRecord"))  
    	dayDetail = component.get("v.record.adsalescloud__Day_and_Time_Details__c");
    if(dayDetail != undefined)  // if JSON found, GUI initializes with JSON
    {
      var result = JSON.parse(dayDetail.replace(/&quot;/g, '\"')).dayParts;                 //
        
            var dayPartMap = {};
            result.forEach(function(value){
                var dayEntry = dayPartMap[value.dayOfWeek];
                var dayPart ={"end": {"hour": ''+value.endTime.hour, "minute": self.toNumber(value.endTime.minute)}, "start": { "hour": ''+value.startTime.hour, "minute": self.toNumber(value.startTime.minute)}};
                if($A.util.isEmpty(dayEntry)){
                    dayPartMap[value.dayOfWeek] = [dayPart];
                }
                else{
                    dayEntry.push(dayPart);   
                    dayPartMap[value.dayOfWeek] = dayEntry;
                }
                
            });            
            Object.keys(dayPartMap);
            days.forEach(function(day, indexA){
                tableData.push({"day": day, "plan": 'Scheduled', "schedules": []});
                if(!$A.util.isEmpty(dayPartMap[day])){
                    dayPartMap[day].forEach(function(value, index){
                        tableData[indexA].schedules.push(value);
                        if(value.start.hour == '0' && value.start.minute == '0' && value.end.hour == '24' && value.end.minute == '0') {
                            tableData[indexA].plan = "Running all day";
                        }
                    });
                }
                else{
                    tableData[indexA].plan = 'Paused';
                    tableData[indexA].schedules.push({'start': {'hour': '0', 'minute': '0'}, 'end': {'hour': '24', 'minute': '0'}}); // default Schedule
                }
            });
    }
    else {								// if JSON not found GUI initializes with default data
      for(var i = 0; i < 7; i++) {
        tableData.push({'day': days[i], 'plan': 'Running all day', 'schedules': [defaultSchedule]});
      }
    }
    component.set("v.tableData", tableData);
  },
    updateJSON: function(component) {
        var dayParts = [];
        var self = this;
        component.get("v.tableData").forEach(function func(value, dayIndex, This) {
            if(value.plan == 'Scheduled' || value.plan == 'Running all day') {
                value.schedules.forEach(function fun(schedule, scheduleIndex) {
                    var dayPart = {'dayOfWeek' : value.day, "endTime": {"hour": parseInt(schedule.end.hour), "minute": self.toWord(schedule.end.minute)}, "startTime": {"hour": parseInt(schedule.start.hour), "minute": self.toWord(schedule.start.minute)}};
                    
                    
                dayParts.push(dayPart);
                });
            }         
        });
        var json = {"dayPartTargeting": {"dayParts": dayParts}};
        component.set("v.record.adsalescloud__Day_and_Time_Details__c", JSON.stringify(json.dayPartTargeting));
        var updateRecordEvent = $A.get('e.c:ProductTemplateRecordUpdateEvent');
        updateRecordEvent.fire();
    },
    toNumber : function(string){
        
        switch(string){
            case 'ZERO':
                return '0';
            case 'THIRTY':
                return '30';
            case 'FIFTEEN':
                return '15';
            case 'FORTY_FIVE':
                return '45';
            default:
                return string;
        }        
    },
    toWord : function(number){
        switch(number){
            case '0':
                return 'ZERO';
            case '30':
                return 'THIRTY';
            case '15':
                return 'FIFTEEN';
            case '45':
                return 'FORTY_FIVE';
            default: 
                return number;
        }
    }
})