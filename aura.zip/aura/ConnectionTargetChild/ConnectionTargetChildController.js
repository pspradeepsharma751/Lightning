({
  doInit: function(component, event, helper) {
    helper.makeTargetsSelected(component);
  },
  handleMenuSelect: function(component, event, helper) {
    var action = event.getParam('value');
    if(action === 'include') {
      component.set('v.included', true);
      component.set('v.showInclude', true);
    }
    else {
      component.set('v.excluded', true);
      component.set('v.showExclude', true);
    }
    helper.fireSelectionEvent(component, action);
  },
  handleUnselection: function(component, event, helper) {
    var segments = component.get('v.segments');
    var eventSegments = event.getParam('segments');
    if(eventSegments !== segments) return;

    var item = event.getParam('item');
    var category = event.getParam('category');
    var parentCategory = event.getParam('parentCategory');
    var adunit = component.get('v.adunit');
    var targets = component.get('v.selectedMap');

    if(category === 'User domains') {
      var domains = component.get('v.domainSelectedValue');
      var domainArr = domains.split(',');
      var ind = domainArr.indexOf(item.adunit.id);
      if(ind !== -1) {
        domainArr.splice(ind, 1);
        component.set('v.domainSelectedValue', domainArr.join());
      }
    }
    else if(item.adunit.id === adunit.id) {
      if(item.action === 'include') {
        component.set('v.included', false);
      } else {
        component.set('v.excluded', false);
      }
    }
    if(targets[parentCategory]) {
      if(!targets[parentCategory][category]) {
        component.set('v.showInclude', false);
        component.set('v.showExclude', false);
      }
    } else {
      component.set('v.showInclude', false);
      component.set('v.showExclude', false);
    }
    /* if(targets) {
      var parentId = (adunit.parentId) ? adunit.parentId : '0000';
      var rootTargets = targets[parentCategory];
      if(rootTargets) {
        var items = rootTargets[category];
        if(items && items[parentId]) {
          var adunits = items[parentId];
          for(var i = 0; i < adunits.length; i++) {
            if(adunits[i].adunit.id === adunit.id) {
              adunits.splice(i, 1);
              break;
            }
          }
          items[parentId] = adunits;
          rootTargets[category] = items;
          targets[category] = rootTargets;
          component.get('v.selectedMap', targets);
        }
      }
    } */
  },
  getRecordsFromDFP: function(component, event, helper) {
    var adunit = component.get('v.adunit');
    var children = component.get('v.children');
    if(children.length === 0 && adunit.name !== 'User domains')
      helper.getAdUnitsFromDFP(component);
    else
      helper.expandChildren(component);
  },
  search: function(component, event, helper) {
    helper.searchConnections(component);
  },
  loadMore: function(component, event, helper) {
    helper.getAdUnitsFromDFP(component);
  },
  collapseNodes: function(component, event, helper) {
    var flag = component.get('v.expand');
    component.set('v.expand', false);
  },
  handleMatchCriteria: function(component, event, helper) {
    helper.domainSelection(component);
  },
  handleDomainAction: function(component, event, helper) {
    helper.domainSelection(component);
  }
})