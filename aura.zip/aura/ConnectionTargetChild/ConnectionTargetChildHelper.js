({
  fireSelectionEvent: function(component, action) {
    this.fireEvent(component, action, component.get('v.adunit'));
  },
  fireEvent: function(component, action, adunit) {
    var compEvent = $A.get('e.c:TargetingEvent');
    var apiName = component.get('v.apiName');
    compEvent.setParams({
      'adunit': adunit,
      'action': action,
      'segments': component.get('v.segments'),
      'category': component.get('v.category'),
      'sub_category': component.get('v.sub_category'),
      'connType': apiName
    });
    compEvent.fire();
  },
  getAdUnitsFromDFP: function(component) {
    var adunit = component.get('v.adunit');
    var offset = component.get('v.offset');
    var fields = component.get('v.fields');
    var pageSize = component.get('v.page_size');
    var flag = component.get('v.flag');
    var searchTerm = component.get('v.searchTerm');
    var self = this;
    var cond;
    if(searchTerm && searchTerm.trim()) {
      cond = this.stringFormat(component.get('v.searchCond'), [fields[1], searchTerm.trim(), fields[1], fields[1], pageSize, (pageSize * offset)]);
    }
    else if(flag)
      cond = this.stringFormat(component.get('v.cond2'), [fields[1], adunit.name, fields[2], pageSize, (pageSize * offset)]);
    else
      cond = this.stringFormat(component.get('v.cond'), [fields[1], fields[1], pageSize, (pageSize * offset)]);

    this.fetchData(component, 'getConnectionChildren', {
      'apiName': component.get('v.apiName'),
      'fields': fields,
      'cond': cond,
      'flag': flag
    }, function(res) {
      if(res.status === 'OK') {
        var oldTargets = component.get('v.children');
        var newTargets = res.targets;
        component.set('v.children', oldTargets.concat(newTargets));
        if(res.count === pageSize) {
          component.set('v.offset', ++offset);
          component.set('v.showMore', true);
        }
        else
          component.set('v.showMore', false);

        self.expandChildren(component);
      }
    });
  },
  searchConnections: function(component) {
    var term = component.get('v.searchTerm');
    var self = this;
    if(term && term.trim()) {
      component.set('v.children', []);
      component.set('v.searchEnabled', true);
      component.set('v.offset', 0);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getAdUnitsFromDFP(component);
      }), 500);
    } else if(component.get('v.searchEnabled')) {
      component.set('v.children', []);
      component.set('v.offset', 0);
      component.set('v.searchEnabled', false);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getAdUnitsFromDFP(component);
      }), 500);
    }
  },
  expandChildren: function(component) {
    component.set('v.expand', true);
  },
  domainSelection: function(component) {
    var action = component.get('v.matchedValue');
    var domains = component.get('v.domainSelectedValue');
    if(domains && domains.trim().length > 0) {
      this.fireEvent(component, action, domains);
    }
  },
  makeTargetsSelected: function(component) {
    try {
      var targets = component.get('v.selectedMap');
      var adunit = component.get('v.adunit');

      if(targets) {
        var parentId = adunit.parentId || '0000';
        var category = component.get('v.category');
        var subCategory = component.get('v.sub_category');
        var rootTargets = targets[category];
        if(rootTargets) {
          var items = rootTargets[subCategory];
          if(items && items[parentId]) {
            var adunits = items[parentId];
            if(subCategory === 'User domains') {
              this.domainValueSelection(component, adunits);
              return;
            }
            for(var index = 0; index < adunits.length; index++) {
              if(adunits[index].adunit.id === adunit.id) {
                if(adunits[index].action === 'include') {
                  component.set('v.included', true);
                  component.set('v.showInclude', true);
                }
                else {
                  component.set('v.excluded', true);
                  component.set('v.showExclude', true);
                }
                break;
              }
            }
          } else if(component.get('v.lineItems') > 0) {
            component.set('v.customizable', false);
          }
        }
      }
    } catch(e) {
      console.log(e.message);
    }
  },
  domainValueSelection: function(component, adunits) {
    var domains = [];
    var action;
    for(var index = 0; index < adunits.length; index++) {
      action = adunits[index].action;
      domains.push(adunits[index].adunit.id);
    }
    component.set('v.matchedValue', action);
    component.set('v.domainSelectedValue', domains.join());
  }
});