({
    fields : ["notes", "allowSameAdvertiserException", "timezone", "start_date", "end_date", "buffer", "quantity", "net_rate", "costAdjustment", "delivery_Impressions",
              "display_Creatives","rotate_Creatives", "goal", "labels"],        
    doInit : function(component) {
        this.fetchTimezoneOptions(component);
        var itemsList = component.get("v.itemsList");
        var skipItemsList;
        var currentTime;
        var PLI_Max_Start_Date;
        var PLI_Min_End_Date;
        var labelsData;
        if(itemsList.length > 0){
            var obj = JSON.parse(JSON.stringify(itemsList[0]));
            var fields = this.fields;
            fields.forEach(function(field){
                obj[field] =  {"value" : obj[field], "isVaries" : false};
            });
            PLI_Max_Start_Date = new Date(obj.start_date.value);
            PLI_Min_End_Date = new Date(obj.end_date.value);
            fields.forEach(function(field, fieldIndex){
                skipItemsList = false;
                itemsList.forEach(function(item){
                    if(!skipItemsList){
                        if(item[field] == obj[field].value){
                            obj[field] = {"value" : item[field], "isVaries" : false, "visible": obj[field].visible,  "disabled": obj[field].disabled};
                        }
                        else{
                            obj[field] = {"value" : null, "isVaries" : true , "visible": obj[field].visible,  "disabled": obj[field].disabled};
                            skipItemsList = true;
                        }
                        
                    }
                    if(fieldIndex == 0){
                        if(item.lineItemType === "Sponsorship"){
                            obj.goal.visible = true;
                        }
                        if(item.lineItemType === "Standard"){
                            obj.quantity.visible = true;
                        }
                        if(item.adServerId){
                            obj.adServerId = true;
                        }
                        if(item.unlimitedEndDateTime){
                            obj.end_date.disabled = true;
                        }
                    }
                    if(field === "start_date"){
                        console.log(item.start_date);
                        var startDate = new Date(item.start_date);
                        var now = new Date();
                        if((startDate < now)  && item.adServerId){
                            obj.start_date.disabled = true;
                        }
                        now.setMinutes(now.getMinutes() + 10);
                        if(obj.start_date.isVaries){ 
                            obj.start_date.value = now.toISOString();
                        }
                        now.setMinutes(now.getMinutes() + now.getTimezoneOffset() /*+ item.timezoneOffset*/);
                        currentTime = now.toLocaleString();
                        console.log(":::   "+currentTime);
                        if(PLI_Max_Start_Date < new Date(item.start_date) ){
                            PLI_Max_Start_Date = new Date(item.start_date);
                        }
                    }
                    if(field === "end_date"){
                        if(PLI_Min_End_Date > new Date(item.end_date) ){
                            PLI_Min_End_Date = new Date(item.end_date);
                        }
                        if(	obj.end_date.isVaries){                            
                            obj.end_date.value = PLI_Min_End_Date.toISOString();
                        }
                    }
                    if(field === "labels"){
                        if(!obj.labels.isVaries){
                            labelsData = {"adsalescloud__Labels__c": item.labels, "adsalescloud__Labels_Detail__c": "", "adsalescloud__Parent_Labels_Details__c": item.parentLabelsDetail};
                        }
                        else{
                            labelsData = {"adsalescloud__Labels__c": "", "adsalescloud__Labels_Detail__c": "", "adsalescloud__Parent_Labels_Details__c": ""};
                        }
                    }
                });
            });
            obj.labels.value = labelsData;
            PLI_Max_Start_Date.setMinutes(PLI_Max_Start_Date.getMinutes() +PLI_Max_Start_Date.getTimezoneOffset());
            PLI_Min_End_Date.setMinutes(PLI_Min_End_Date.getMinutes() + PLI_Min_End_Date.getTimezoneOffset());
            obj.start_date.max = PLI_Min_End_Date.toLocaleString() ; //Date.parse(new Date(new Date().getTime()).toLocaleString('en-US', {timeZone: timezone}));
            obj.end_date.min = PLI_Max_Start_Date.toLocaleString();
            console.log(currentTime);
            component.set("v.currentTime", currentTime);
            component.set("v.item", obj);
        }
    },
    fetchTimezoneOptions: function(component) {
        var action = component.get('c.fetchPicklistValues');
        action.setParams({
            'pickListFieldName': 'timezone'
            
        });
        action.setCallback(this,function(response) {                           
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var timezoneOptionsList = [];
                var listPicklistValues = response.getReturnValue();
                for(var i = 0; i < listPicklistValues.length; i++) {
                    timezoneOptionsList.push({
                        class: 'optionClass',
                        label: listPicklistValues[i].label,
                        value: listPicklistValues[i].value,
                        selected: component.get('v.item').timezone.value !== undefined && listPicklistValues[i].value === component.get('v.item').timezone.value
                    });
                }
                var obj = component.get("v.item");
                if(obj.timezone.isVaries){
                    obj.timezone.value = timezoneOptionsList[0].value;
                }
                component.set('v.timezoneOptions', timezoneOptionsList);
                component.set("v.item", obj);
                this.handleTimezoneChange(component);
            }
            else if(state === 'ERROR') {
                var errorMessage = response.getError()[0].message;
                component.set('v.errorMessage', errorMessage);
            }
        }
                          );
        $A.enqueueAction(action);
    },
    validate : function(component){
        var item = component.get("v.item");
        var error = '';
        
        
        
        
        
        var timezone = item.timezone.value;
        var currentDate = Date.parse(new Date(new Date().getTime()).toLocaleString('en-US', {timeZone: timezone}));
        var startDate = Date.parse(new Date(item.start_date.value).toLocaleString('en-US', {timeZone: timezone}));
        var endDate = Date.parse(new Date(item.end_date.value).toLocaleString('en-US', {timeZone: timezone}));
        var maxStartDate = new Date(item.start_date.max);
        
        try{
            let inputFields = Array.isArray(component.find('formField')) ? component.find('formField') : [component.find('formField')];
            let dateFieldValidity = inputFields.reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
            if(!dateFieldValidity)
                error = 'Invalid Data. Please review all fields.';
        }catch(e){}
        
        
        
        if(!error){
            if(!item.end_date.isVaries){
                if( !item.start_date.isVaries  && ( endDate < startDate)) {                
                    error = 'End Date must be greater than Start Date.';
                }
                else if(!item.adServerId && (endDate < currentDate)){
                    error = 'End Date cannot be in the past.';
                }
            }
            if(!item.adServerId && !item.start_date.isVaries  &&  (startDate < currentDate)) {
                error = 'Start Date cannot be in the past.';
            }
            if(!item.adServerId  && !item.start_date.isVaries && !(maxStartDate > startDate && startDate > currentDate)){
                error = 'Invalid Start Date. Please choose a valid Start Date.';
            }
            if($A.util.isEmpty(item.end_date.value)  &&  (!item.end_date.isVaries /*|| !item.start_date.isVaries*/)){
                error = 'Please choose a End Date.';
            }
            if(!item.start_date.isVaries && $A.util.isEmpty(item.start_date.value)){
                error = 'Please choose a Start Date.';
            }
        }        
        if(error){
            component.set("v.toast", {"message": error, "type" : "error", "closable" : true, "autoHide" : true, "timeout" : 3000});
            return false;
        }
        return true;
    },
    confirm : function(component) {
        var obj = component.get("v.item");
        var itemsList = component.get("v.itemsList");
        var fields = this.fields;
        fields.forEach(function(field, fieldIndex){
            itemsList.forEach(function(item){
                item.isModified = true;
                if(!obj[field].isVaries){
                    if(field != "labels"){
                        item[field] = obj[field].value;
                    } 
                    else{
                        item.labels = obj.labels.value.adsalescloud__Labels__c;
                        item.labelsDetails = obj.labels.value.adsalescloud__Labels_Detail__c;
                        item.parentLabelsDetail = obj.labels.value.adsalescloud__Parent_Labels_Details__c;                        
                    }               
                }
            });
        });
        component.set("v.isAnythingChanged", true);
        component.set("v.itemsList", itemsList);
        component.set("v.show", false);
    },  
    handleTimezoneChange : function(component) {
        var timezoneOffsetMinutesMap = component.get("v.timezoneOffsetMinutesMap");
        var item = component.get("v.item");
        var now = new Date();
        now.setMinutes(now.getMinutes() + now.getTimezoneOffset() +10 /*+ timezoneOffsetMinutesMap[item.timezone.value]*/); // no need to add timezoneOffsetMinutes since toLocaleString() does not has timezone. 
        component.set("v.currentTime", now.toLocaleString());
        this.refreshDateTimeComponents(component);
    },
    refreshDateTimeComponents : function(component){
        component.set("v.refreshDateTimeComponents", true);
        component.set("v.refreshDateTimeComponents", false);
    },
})

/*
var startDate = record.adsalescloud__Start_Date__c;
    var endDate = record.adsalescloud__End_Date__c;

    if(startDate && endDate && record.adsalescloud__Rate_Type__c === 'CPD') {
      var d1 = new Date(startDate);
        d1.setMinutes(d1.getMinutes() + (new Date().getTimezoneOffset() + component.get("v.timezoneOffsetMinutes")));
        d1.setHours(0);  d1.setMinutes(0); 
      var d2 = new Date(endDate);
        d2.setMinutes(d2.getMinutes() + (new Date().getTimezoneOffset() + component.get("v.timezoneOffsetMinutes")));
      component.set('v.errorMessage', '');

*/