({
	doInit: function(component) {
       var getRecord = component.get('c.getRecordName');
        getRecord.setParams({
          'fieldId': component.get("v.fieldId"),
          'ObjectName' : component.get("v.objectAPIName"),
        });
        getRecord.setCallback(this,
          function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
              var selectedRecord = response.getReturnValue(); 
              this.handleComponentEvent(component, event, selectedRecord);
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
             component.set('v.showSpinner', false); 
          }
        );
        $A.enqueueAction(getRecord);
      },
    
    searchHelper : function(component,event,getInputkeyWord) {
	  // call the apex class method 
     var action = component.get("c.fetchLookUpValues");
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : component.get("v.objectAPIName"),
            'fieldName' : component.get("v.fieldName")
          });
        action.setCallback(this, function(response) {
          $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
              // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", '');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
 
        });
        $A.enqueueAction(action);
    
	},
     handleComponentEvent : function(component, event,selectedRecord) {
        var forclose = component.find("lookup-pill"); // for closing the lightning pill record.
           $A.util.addClass(forclose, 'slds-show');
           $A.util.removeClass(forclose, 'slds-hide');
  
        var forclose = component.find("searchRes");
           $A.util.addClass(forclose, 'slds-is-close');
           $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
           $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show'); 
         
         var searchIcon = component.find("searchIcon");
           $A.util.addClass(searchIcon, 'slds-hide');
           $A.util.removeClass(searchIcon, 'slds-show');
         
         var fieldName = component.get("v.fieldName");
         component.set("v.record["+fieldName+"]" ,selectedRecord.Id);
         component.set("v.selectedRecord" , selectedRecord); 
	},
})