({
	doInit : function(component) {
        var action = component.get('c.getAuthenticationSetting');
        action.setParams({ context : component.get("v.state") });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(state == 'SUCCESS'){
                var auth = response.getReturnValue();
                var setting = auth.setting;
                console.log(setting);
                var url = 'https://accounts.google.com/o/oauth2/auth?response_type=code&client_id='+setting.adsalescloud__Client_Id__c+'&redirect_uri='+setting.adsalescloud__Redirection_URL__c+'&scope='+setting.adsalescloud__Scope__c+'&access_type=offline&approval_prompt=force&state='+component.get('v.state');
                component.set('v.url',url);
                if(auth && auth.tokens && auth.tokens.LastModifiedDate){
                    auth.tokens.LastModifiedDate = $A.localizationService.formatDateTime(auth.tokens.LastModifiedDate);
                    component.set('v.tokens',auth.tokens);
                }
            }
            else if(state == 'ERROR') {
                var errors = response.getError();
                console.log(errors);
            }
        });
        $A.enqueueAction(action);
	}
})