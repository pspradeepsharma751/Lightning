({
    doInit : function(component, event, helper) {        
        helper.doInit(component);
    },
    loadBuyerData : function(component, event, helper) {
        helper.doInit(component);
    },
    updateSelectedOptions : function(component, event, helper) {
        helper.updateSelectedOptions(component);
    },
    showModal : function(component, event, helper) {
        component.set("v.showModal",true);
        if(!$A.util.isEmpty(component.get("v.onclickAction"))){
            $A.enqueueAction(component.get("v.onclickAction"));
        }
    },
    closeModal : function(component, event, helper) {
        component.set("v.showModal",false);
    },
    updateSelectedOptionValue : function(component, event, helper) {
        helper.updateSelectedOptionValue(component);
    },
    
    search: function(component,event,helper){
        //helper.searchKeysHandler(component);
        var term = component.get('v.searchTerm');
        var self = helper;
        if(term && term.trim()) {
            self.doInit(component);
            component.set('v.searchEnabled', true);
        } else if(component.get('v.searchEnabled')) {
            self.doInit(component);
            component.set('v.searchEnabled',false);
            
        }
    }
})