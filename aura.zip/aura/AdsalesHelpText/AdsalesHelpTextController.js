({
  handleOnClick : function(component, event, helper) {
    $A.util.toggleClass(component.find("divHelp"), 'hide__popover');
  },
  handleMouseLeave : function(component, event, helper) {
    $A.util.addClass(component.find("divHelp"), 'hide__popover');
  },
  handleMouseEnter : function(component, event, helper) {
    $A.util.removeClass(component.find("divHelp"), 'hide__popover');
  },
})