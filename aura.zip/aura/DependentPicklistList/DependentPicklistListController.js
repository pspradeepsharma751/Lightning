({
  doInit: function(component, event, helper) {
    helper.fetchAllPicklistValues(component);
  },
  toggleVisibilty:function(component,event,helper){
    helper.toggleVisibilty(component);
  }
});