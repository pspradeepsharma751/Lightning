({
  doInit: function(component) {
    var totalNoOfRecords = component.get('v.totalNoOfRecords');
    var noOfRecordToDisplay = component.get('v.noOfRecordToDisplay');
    var totalNoOfPage = totalNoOfRecords / noOfRecordToDisplay;
    component.set('v.totalNoOfPage', Math.ceil(totalNoOfPage));
    // if no record found display message on screen.
    if(totalNoOfRecords === 0) {
      component.set('v.isRecordListEmpty', true);
    }
    var currentPageNo = 1;
    this.recordToDisplay(component, currentPageNo);
  },
  hasPrevious: function(component) {
    var currentPageNo = component.get('v.currentPageNo');
    component.set('v.currentPageNo', currentPageNo--);
    this.recordToDisplay(component, currentPageNo);
  },

  onPageNoClick: function(component, event) {
    var currentPageNo = event.getSource().get('v.label');
    this.recordToDisplay(component, currentPageNo);
  },

  hasNext: function(component) {
    var pageNoList = component.get('v.pageNoList');
    var endPageNo = component.get('v.endPageNo');
    var totalNoOfPage = component.get('v.totalNoOfPage');
    if(endPageNo < totalNoOfPage) {
      endPageNo++
      pageNoList.push(endPageNo);
      component.set('v.endPageNo', endPageNo);
      component.set('v.pageNoList', pageNoList);
      var currentPageNo = component.get('v.currentPageNo');
      component.set('v.currentPageNo', currentPageNo++);
      this.recordToDisplay(component, currentPageNo);
    }

  },
  recordToDisplay: function(component, currentPageNo) {
    var noOfRecordToDisplay = component.get('v.noOfRecordToDisplay');
    var startIndex = noOfRecordToDisplay * (currentPageNo - 1);
    var endIndex = noOfRecordToDisplay * currentPageNo;
    var productList = component.get('v.productList');
    var paginationList = [];
    var totalNoOfRecords = component.get('v.totalNoOfRecords');
    for(var recordNo = startIndex; recordNo < endIndex; recordNo++) {
      if(recordNo < totalNoOfRecords)
        paginationList.push(productList[recordNo]);
    }
    component.set('v.currentPageNo', currentPageNo);
    component.set('v.paginationList', paginationList);

  },
})