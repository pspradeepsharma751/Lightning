({

  doInit: function(component, event, helper) {
    helper.doInit(component);
  },
  closeModel: function(component, event, helper) {
    component.set('v.isOpen', false);
  },
  hasPrevious: function(component, event, helper) {
    helper.hasPrevious(component);
  },
  onPageNoClick: function(component, event, helper) {
    helper.onPageNoClick(component, event);
  },
  hasNext: function(component, event, helper) {
    var noOfRecordToDisplay = component.get('v.noOfRecordToDisplay');
    var totalNoOfRecords = component.get('v.totalNoOfRecords');
    if(noOfRecordToDisplay < totalNoOfRecords)
      helper.hasNext(component);
  },

})