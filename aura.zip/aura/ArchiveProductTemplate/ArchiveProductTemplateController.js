({
    doInit : function(component, event, helper){
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem; transform: inherit !important;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(50vh - 210px);}</style>');
        helper.doInit(component);     
    },
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
        if(component.get("v.hideUserPrompt"))
            $A.get('e.force:refreshView').fire();
    },
    archive: function (component, event, helper) {
        component.set("v.message", "Processing...");
        component.set("v.messageType", "info");
        //component.set("v.showSpinner", true);
        helper.archive(component);
    },
})