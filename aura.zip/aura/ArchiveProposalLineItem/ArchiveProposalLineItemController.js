({
    doInit: function(component, event, helper) {
        helper.doInit(component);
    },
	archiveRecord : function (component, event, helper) {
        helper.archiveRecord(component);
    },
    
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
    },
})