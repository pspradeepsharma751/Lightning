({
    doInit: function(component) {
        if(component.get("v.sObjectName") == 'adsalescloud__Proposal__c') 
        	var action = component.get("c.getProposalRecord");
        else
            var action = component.get("c.getPLIRecord");
        
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var record = JSON.parse(response.getReturnValue());
                component.set('v.record', record);
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    archiveRecord:function (component) {
        component.set("v.loading",true);
        component.set("v.showToast",true);
        var action = component.get("c.archiveObjRecord");
        action.setParams({
            sObjectRecord: JSON.stringify(component.get("v.record")),
            objName: component.get("v.sObjectName")
        });
        
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
            var state = response.getState();
            if(state === "SUCCESS") {
                $A.get('e.force:refreshView').fire();
                $A.get("e.force:closeQuickAction").fire();
                /*
                var recid = component.get("v.recordId");
                window.location.href = "/"+recid;*/
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
})