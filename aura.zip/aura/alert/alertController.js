({
	doInit : function(component, event, helper) {
		var type = component.get("v.type");
        var style= "";
        if(type === "error"){
            style += "."+component.getName()+" .box{border-color: rgba(255, 0, 0, 0.62) !important;} ";
            style += "."+component.getName()+" .slds-modal__container {width: 50%!important;} ";
        }
        component.set("v.style", "<style>"+style+"</style>");
	}
})