({
	doInit : function(component) {
        var contendingLineItems = this.getContendingLineItems(component);
        component.set("v.paginationInfo", 
                      {
                          "currentPage": 1, "totalPages": parseInt(contendingLineItems.length / 10) + 1, "pageSize": 10, 
                          "buttonDisplayInfo":{
                              "showButtons": true, "disableBack": true, "disableNext": contendingLineItems.length <= 10
                          }
                      }
                     );
        this.changeProductPage(component, 0);
    },
    getContendingLineItems: function(component){
        if(component.get("v.lineItemDisplayPriority") === "higherPriority"){
            return component.get("v.contendingLineItemData").higherPriority;
        }
        else{
            return component.get("v.contendingLineItemData").lowerPriority;
        }
    },
    changeProductPage: function(component, page){
        var paginationInfo = component.get("v.paginationInfo");
        paginationInfo.currentPage += page;
        var productViewList = this.getContendingLineItems(component).slice((paginationInfo.currentPage - 1) * 10 , (paginationInfo.currentPage * 10));
        if(paginationInfo.currentPage >= paginationInfo.totalPages){
            paginationInfo.buttonDisplayInfo.disableNext = true;
        }else{
            paginationInfo.buttonDisplayInfo.disableNext = false;
        }
        if(paginationInfo.currentPage > 1){
            paginationInfo.buttonDisplayInfo.disableBack = false;
        }
        else{
            paginationInfo.buttonDisplayInfo.disableBack = true;
        }
        component.set("v.paginationInfo", paginationInfo);
        component.set("v.contendingLineItems", productViewList);
    },
})