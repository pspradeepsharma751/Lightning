({
  timeout: null,
  fireSelectionEvent: function(component, action) {
    this.fireEvent(component, action, component.get('v.adunit'));
  },
  fireEvent: function(component, action, adunit) {
    var compEvent = $A.get('e.c:TargetingEvent');
    var apiName = component.get('v.apiName');
    compEvent.setParams({
      'adunit': adunit,
      'action': action,
      'segments': component.get('v.segments'),
      'category': component.get('v.category'),
      'sub_category': component.get('v.sub_category'),
      'connType': apiName
    });
    compEvent.fire();
  },
  search: function(component) {
    var term = component.get('v.searchTerm');
    var self = this;
    if(term && term.trim()) {
      component.set('v.children', []);
      component.set('v.searchEnabled', true);
      component.set('v.offset', 0);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getTargetsFromDFP(component);
      }), 500);
    } else if(component.get('v.searchEnabled')) {
      component.set('v.children', []);
      component.set('v.offset', 0);
      component.set('v.searchEnabled', false);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getTargetsFromDFP(component);
      }), 500);
    }
  },
  getTargetsFromDFP: function(component) {
    var adunit = component.get('v.adunit');
    var apiName = component.get('v.apiName');
    var offset = component.get('v.offset');
    var fields = component.get('v.fields');
    var pageSize = component.get('v.page_size');
    var sub_category = component.get('v.sub_category');
    var flag = component.get('v.flag');
    var level = component.get('v.level');
    var searchTerm = component.get('v.searchTerm');
    var self = this;
    var cond;
    if((searchTerm && searchTerm.trim())) {
      cond = this.stringFormat(component.get('v.searchCond'), [fields[1], searchTerm.trim(), fields[1], pageSize, (pageSize * offset)]);
    }
    else if(flag || level === 2) {
      var sub_subCategory = component.get('v.sub_subCategory');
      var sub_obj = (level === 2) ? {'apiName': 'Mobile_Device_Submodel', 'fields': ['id', 'MobileDeviceSubmodelName', 'MobileDeviceId'], 'relationField': 'MobileDeviceId'} : sub_subCategory[sub_category];
      apiName = sub_obj['apiName'];
      fields = sub_obj['fields'];
      cond = this.stringFormat(component.get('v.cond2'), [sub_obj['relationField'], adunit.id, fields[1], pageSize, (pageSize * offset)]);
    } else
      cond = this.stringFormat(component.get('v.cond'), [fields[1], pageSize, (pageSize * offset)]);

    this.fetchData(component, 'getDeviceTargets', {
      'apiName': apiName,
      'fields': fields,
      'cond': cond,
      'targetName': flag ? adunit.name : ''
    }, function(res) {
      if(res.status === 'OK') {
        var oldTargets = component.get('v.children');
        var newTargets = res.targets;
        component.set('v.children', oldTargets.concat(newTargets));
        if(res.count === pageSize) {
          component.set('v.offset', ++offset);
          component.set('v.showMore', true);
        }
        else
          component.set('v.showMore', false);

        self.expandChildren(component);
      }
    });
  },
  expandChildren: function(component) {
    component.set('v.expand', true);
  },
  makeTargetsSelected: function(component) {
    try {
      var targets = component.get('v.selectedMap');
      var adunit = component.get('v.adunit');

      if(targets) {
        var parentId = (adunit.parentId) ? adunit.parentId : '0000';
        var category = component.get('v.category');
        var subCategory = component.get('v.sub_category');
        var rootTargets = targets[category];
        if(rootTargets) {
          var items = rootTargets[subCategory];
          if(items && items[parentId]) {
            var adunits = items[parentId];
            for(var i = 0; i < adunits.length; i++) {
              if(adunits[i].adunit.id === adunit.id) {
                if(adunits[i].action === 'include') {
                  component.set('v.included', true);
                  component.set('v.showInclude', true);
                }
                else {
                  component.set('v.excluded', true);
                  component.set('v.showExclude', true);
                }
                break;
              }
            }
          } else if(component.get('v.lineItems') > 0) {
            component.set('v.customizable', false);
          }
        }
      }
    } catch(e) {console.log(e.message);}
  }
});