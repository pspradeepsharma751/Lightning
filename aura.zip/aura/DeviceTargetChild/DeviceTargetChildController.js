({
  doInit: function(component, event, helper) {
    var level = component.get('v.level');
    var sub_category = component.get('v.sub_category');
    if(level === 2) {
      if(sub_category === 'Operating System')
        component.set('v.sub_category', 'Operating System Versions');
      else
        component.set('v.sub_category', 'Mobile devices');
    }
    else if(level === 3)
      component.set('v.sub_category', 'Mobile devices submodels');

    var customizableValues = {
      'Browser': 'allowBrowserTargetingCustomization',
      'Browser Language': 'allowBrowserLanguageTargetingCustomization',
      'Device Capability': 'allowDeviceCapabilityTargetingCustomization',
      'Device Category': 'allowDeviceCapabilityTargetingCustomization',
      'Device Manufacturer': 'allowMobileDeviceAndManufacturerTargetingCustomization',
      'Operating System': 'allowOperatingSystemTargetingCustomization',
      'Operating System Versions': 'allowOperatingSystemTargetingCustomization',
      'Mobile devices': 'allowMobileDeviceAndManufacturerTargetingCustomization',
      'Mobile devices submodels': 'allowMobileDeviceAndManufacturerTargetingCustomization'
    };
    var productCustomAttrDetails = component.get('v.productCustomAttrDetails');
    sub_category = component.get('v.sub_category');

    if(!productCustomAttrDetails || (productCustomAttrDetails && productCustomAttrDetails[customizableValues[sub_category]]))
      component.set('v.editable', true);
    helper.makeTargetsSelected(component);
  },
  searchDeviceHandler: function(component, event, helper) {
    helper.search(component);
  },
  handleMenuSelect: function(component, event, helper) {
    var sub_category = component.get('v.sub_category');
    var action = event.getParam('value');
    if(action === 'include') {
      component.set('v.included', true);
      if(sub_category !== 'Device Capability' && sub_category !== 'Device Category')
        component.set('v.showInclude', true);
    }
    else {
      component.set('v.excluded', true);
      if(sub_category !== 'Device Capability' && sub_category !== 'Device Category')
        component.set('v.showExclude', true);
    }
    helper.fireSelectionEvent(component, action);
  },
  handleUnselection: function(component, event, helper) {
    var segments = component.get('v.segments');
    var eventSegments = event.getParam('segments');
    if(eventSegments !== segments) return;
    var item = event.getParam('item');
    var category = event.getParam('category');
    var parentCategory = event.getParam('parentCategory');
    var adunit = component.get('v.adunit');
    var targets = component.get('v.selectedMap');

    if(item.adunit.id !== adunit.id) return;

    if(item.action === 'include') {
      component.set('v.included', false);
    } else {
      component.set('v.excluded', false);
    }
    if(targets[parentCategory]) {
      if(!targets[parentCategory][category]) {
        component.set('v.showInclude', false);
        component.set('v.showExclude', false);
      }
    } else {
      component.set('v.showInclude', false);
      component.set('v.showExclude', false);
    }

    /* if(targets) {
      var parentId = (adunit.parentId) ? adunit.parentId : '0000';
      var rootTargets = targets[parentCategory];
      if(rootTargets) {
        var items = rootTargets[category];
        if(items && items[parentId]) {
          var adunits = items[parentId];
          for(var i = 0; i < adunits.length; i++) {
            if(adunits[i].adunit.id === adunit.id) {
              adunits.splice(i, 1);
              break;
            }
          }
          items[parentId] = adunits;
          rootTargets[category] = items;
          targets[category] = rootTargets;
          component.get('v.selectedMap', targets);
        }
      }
    } */
  },
  getRecordsFromDFP: function(component, event, helper) {
    var children = component.get('v.children');
    if(children.length === 0)
      helper.getTargetsFromDFP(component);
    else
      helper.expandChildren(component);
  },
  loadMore: function(component, event, helper) {
    helper.getTargetsFromDFP(component);
  },
  collapseNodes: function(component, event, helper) {
    component.set('v.expand', false);
  },
  handleValueAction: function(component, event, helper) {
    component.set('v.included', false);
    component.set('v.excluded', false);
  }
});