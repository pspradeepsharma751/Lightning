({
	doInit: function(component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}</style>');
        helper.initializeUtilsHelper(component);
        helper.getAvailabilityForecast(component);
    },
    
    showHideModal: function(component,event,helper) {
    	//component.set('v.show', false);
  	},
    
    gotToRecord: function(component, event, helper) {
        component.set('v.show', false);
    }
})