({
    doInit: function(component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}</style>');
        helper.initializeUtilsHelper(component);
        var sObjectName = component.get('v.sobjectName');
        /*if(sObjectName === 'adsalescloud__Proposal_Line_Item__c')
        	helper.validateRecord(component);
        else*/
        	helper.getAvailabilityForecast(component);
    },
    gotToRecord: function(component, event, helper) {
        if(component.get('v.isLightning')) {
            $A.get('e.force:closeQuickAction').fire();
        } 
        else{
            var navEvt = $A.get('e.force:navigateToSObject');
            navEvt.setParams({
                'recordId': component.get('v.recordId'),
                'slideDevName': 'detail'
            });
            navEvt.fire();
        }
    }
});