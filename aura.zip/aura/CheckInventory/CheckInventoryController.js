({
    doInit : function(component, event, helper){
        helper.doInit(component);
        helper.createTimezoneSelectComponent(component);
    }, 
    
    handleClick : function(component, event,helper) {
        helper.getTimeZoneOffset(component,event);
        //helper.validateData(component, event);
    },
    
    onTypeChange: function(component, event, helper) {
        helper.onLineItemTypeChange(component,event);
    },
        
    onPriorityChange: function(component, event, helper) {
    	helper.onLineItemPriorityChange(component,event);
  	},
    
    onGoalChange: function(component, event, helper){
        helper.onGoalTypeChange(component,event);
    },
    
    getSelectedAccRecord: function(component, event, helper) {
  	  helper.getSelectedAccRecord(component);
  	},
    
    startDateChangeHandler: function(component, event, helper){
      helper.toggleEndDateValue(component,event);  
    },
    toggleEndDateDisplay : function(component, event, helper){
        if(component.get('v.lineItemObject.unlimitedEndDateTime')){
            component.set('v.displayEndDateField', false)
        } else {
            component.set('v.displayEndDateField', true)
        }
            
    },
    
})