({
  getAvailabilityForecast: function(component) {
    var recordId = component.get('v.recordId');
      var checkAvailabilityDateData = component.get("v.checkAvailabilityDateData");
    this.fetchData(component, 'getForecastAvailability',
      {
        recordId: recordId,
        apiName: 'Product2',
        isForecastingSummary: false,
          isMaxAvailable:true ,
          startDateMillis : new Date(checkAvailabilityDateData.startDate).getTime(),
          endDateMillis : new Date(checkAvailabilityDateData.endDate).getTime(),
          timezone : checkAvailabilityDateData.timezone
      }, function(res) {
        if(res.status === 'OK')
          component.set('v.data', res.data);
        else
          component.set('v.error',res.message);
        component.set('v.loading',false);
      });

  }
})