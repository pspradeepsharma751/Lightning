({
	saveAdSalesAuthenticationSetting : function(component, event, helper) {
        helper.saveAdSalesAuthenticationSetting(component,event);
	},
    getAdSalesAuthenticationSetting : function(component, event, helper) {
     	helper.getAdSalesAuthenticationSetting(component, event);
	}
})